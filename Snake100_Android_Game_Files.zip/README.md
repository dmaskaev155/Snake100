# Змейка 100

Android-проект игры «Змейка 100».

- Application ID: `com.snake100.game`
- Версия: `1.0` (versionCode 1)
- Java + Android WebView
- Игровая HTML-страница хранится локально в `app/src/main/assets/index.html`
- Интернет-разрешения не запрашиваются
- Верхняя строка состояния скрыта, нижняя системная навигация остаётся
- GitHub Actions собирает debug APK

## Сборка локально

Требуется JDK 17 и Android SDK 34:

```bash
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

## Сборка через GitHub

Загрузите содержимое репозитория в GitHub. Workflow `.github/workflows/build-apk.yml`
запускается при push в main/master или вручную через Actions. Готовый APK будет
доступен в Artifacts запуска workflow.

## Важно

Это первая оболочка Android вокруг HTML-игры. Перед публикацией/распространением
нужно протестировать на реальном устройстве: сенсорное управление, системную
кнопку «Назад», сохранение рекорда и прохождение уровней.
