package com.snake100.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;

public class MainActivity extends Activity {
    private WebView webView;
    private ToneGenerator toneGenerator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 5, 7));
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideStatusBarKeepNavigation();

        toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 65);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(17, 24, 26));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new AndroidSoundBridge(), "AndroidSound");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidSoundBridge {
        @JavascriptInterface
        public void playSound(String name) {
            if (toneGenerator == null || name == null) return;
            int tone;
            int duration;
            switch (name) {
                case "eat": tone = ToneGenerator.TONE_PROP_BEEP2; duration = 90; break;
                case "crash": tone = ToneGenerator.TONE_CDMA_ABBR_ALERT; duration = 300; break;
                case "level": tone = ToneGenerator.TONE_PROP_ACK; duration = 220; break;
                case "pause": tone = ToneGenerator.TONE_PROP_BEEP; duration = 100; break;
                case "resume": tone = ToneGenerator.TONE_PROP_PROMPT; duration = 130; break;
                case "start": tone = ToneGenerator.TONE_PROP_BEEP; duration = 70; break;
                default: return;
            }
            toneGenerator.startTone(tone, duration);
        }
    }

    private void hideStatusBarKeepNavigation() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideStatusBarKeepNavigation();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        hideStatusBarKeepNavigation();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        if (toneGenerator != null) {
            toneGenerator.release();
            toneGenerator = null;
        }
        super.onDestroy();
    }
}
