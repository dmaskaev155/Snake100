# Змейка 100 — обновлённый Android-проект

- Application ID: `com.snake100.game`
- Версия приложения: `1.1` (versionCode 2)
- Android Java + WebView; игра на 100 уровней находится в `app/src/main/assets/index.html`.
- На каждом уровне требуется собрать ровно 7 предметов еды.
- Выбор скорости: медленно 240 мс, нормально 200 мс, быстро 165 мс. Выбор сохраняется на устройстве.
- Звуковые сигналы воспроизводятся нативно через Android `ToneGenerator`; аудиофайлы в HTML не добавляются.
- Интернет-разрешения не запрашиваются; нижняя системная навигация остаётся доступной.

## Сборка

Требуется JDK 17 и Android SDK 34:

```bash
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

Положите этот ZIP в корень репозитория под именем `Snake100_Android_Game_Files.zip`, затем создайте workflow `.github/workflows/build-apk.yml` по коду из инструкции в чате. Workflow распакует проект и соберёт APK.
