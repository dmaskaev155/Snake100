# SNAKE 100 — Android project v1.2

- Новая HTML-логика уровней из переданного index.html.
- Проверка карт: связность, тупики и отличие уровней.
- 7 предметов еды на каждом уровне.
- Выбор скорости 240 / 200 / 165 мс с сохранением.
- Звуки через Android ToneGenerator и мост AndroidSound.
- Стартовая заставка splash.png.

Пакет: com.snake100.game
Версия: 1.2 (versionCode 3)
